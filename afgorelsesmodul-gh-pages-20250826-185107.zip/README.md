# Afgørelsesmodul (Simpel) · Standalone til GitHub Pages

Denne mappe er *klar* til at blive uploadet direkte til **GitHub Pages**.

## Udgivelse
1. Opret et nyt repo på GitHub (fx `afgorelsesmodul-mockup`).
2. Upload filerne `index.html` og `.nojekyll` til roden af repoet.
3. Gå til **Settings → Pages**.
4. Under **Build and deployment**, vælg **Source: Deploy from a branch**.
5. Vælg **Branch: `main`** og **Folder: `/` (root)** → **Save**.
6. Brug URL'en: `https://<brugernavn>.github.io/<repo-navn>/`

Bemærk: Siden bruger React + Tailwind fra CDN, så der er ingen build eller installation for seere.
